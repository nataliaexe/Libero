import { motion } from 'framer-motion';

// Framer Motion não interpola gradientes CSS; por isso o gradiente de cada
// estado vem de uma classe (avatar-<estado>) e só escala/gira/brilha é animado.
const variantes = {
  idle: {
    scale: [1, 1.05, 1],
    boxShadow: '0 0 20px rgba(124, 92, 191, 0.5)',
    transition: { duration: 4, repeat: Infinity, ease: 'easeInOut' },
  },
  ouvindo: {
    scale: [1, 1.1, 1],
    boxShadow: '0 0 40px rgba(63, 185, 80, 0.8)',
    transition: { duration: 1, repeat: Infinity, ease: 'easeInOut' },
  },
  falando: {
    scale: [1, 1.05, 0.95, 1],
    boxShadow: '0 0 50px rgba(88, 166, 255, 0.9)',
    transition: { duration: 0.5, repeat: Infinity, ease: 'easeInOut' },
  },
  pensando: {
    rotate: [0, 360],
    transition: { duration: 2, repeat: Infinity, ease: 'linear' },
  },
};

const ROTULOS = {
  idle: 'Estou aqui',
  ouvindo: 'Ouvindo você',
  falando: 'Falando',
  pensando: 'Pensando',
};

export default function LiberoAvatar({ estado = 'idle', grande = false }) {
  return (
    <div className={`avatar-wrap ${grande ? 'grande' : ''}`}>
      <motion.div
        className={`avatar avatar-${estado}`}
        variants={variantes}
        initial="idle"
        animate={estado}
      >
        <span>{estado === 'pensando' ? '…' : '✨'}</span>
      </motion.div>
      <p className="avatar-rotulo">{ROTULOS[estado] || ROTULOS.idle}</p>
    </div>
  );
}
