import LiberoAvatar from './LiberoAvatar.jsx';

// Visão do idoso: tela limpa, avatar grande no centro.
export default function ModoTV({ estado, onVoltar }) {
  return (
    <div className="modo-tv">
      <LiberoAvatar estado={estado} grande />
      <button className="voltar" onClick={onVoltar}>Voltar</button>
    </div>
  );
}
