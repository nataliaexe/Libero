import { useCallback, useEffect, useRef, useState } from 'react';
import { req } from '../api.js';

const ROTULOS = { idoso: 'Dona Maria', libero: 'Libero', cuidador: 'Família' };

// Fala a resposta do Libero e devolve o avatar aos estados corretos.
function falar(texto, setEstado) {
  setEstado('idle');
  if (!texto || !('speechSynthesis' in window)) return;
  const fala = new SpeechSynthesisUtterance(texto);
  fala.lang = 'pt-BR'; // o Libero responde em português, por design do companion.py
  fala.onstart = () => setEstado('falando');
  fala.onend = () => setEstado('idle');
  fala.onerror = () => setEstado('idle');
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(fala);
}

export default function Chat({ idosoId, setEstado }) {
  const [mensagens, setMensagens] = useState([]);
  const [texto, setTexto] = useState('');
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState('');
  const fimRef = useRef(null);

  const carregar = useCallback(async () => {
    try {
      const dados = await req(`/chat/${idosoId}/mensagens?limite=50`);
      // A API devolve do mais recente para o mais antigo; exibimos em ordem cronológica.
      setMensagens([...(dados.mensagens || [])].reverse());
      setErro('');
    } catch (e) {
      setErro(e.message);
    }
  }, [idosoId]);

  useEffect(() => {
    carregar();
    const intervalo = setInterval(carregar, 5000);
    return () => clearInterval(intervalo);
  }, [carregar]);

  useEffect(() => {
    fimRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [mensagens]);

  async function enviar(evento) {
    evento.preventDefault();
    const msg = texto.trim();
    if (!msg || enviando) return;

    setEnviando(true);
    setErro('');
    setEstado('pensando');
    try {
      const resposta = await req(`/chat/${idosoId}/mensagem`, {
        method: 'POST',
        body: JSON.stringify({ texto: msg }),
      });
      setTexto('');
      await carregar();
      falar(resposta.resposta, setEstado);
    } catch (e) {
      setErro(e.message);
      setEstado('idle');
    } finally {
      setEnviando(false);
    }
  }

  return (
    <section className="cartao chat">
      <h2>Conversas</h2>
      {erro && <p className="erro">{erro}</p>}

      <div className="mensagens">
        {mensagens.length === 0 && <p className="vazio">Nenhuma mensagem ainda.</p>}
        {mensagens.map((m) => (
          <div key={m.id} className={`bolha ${m.autor}`}>
            <strong>{ROTULOS[m.autor] || m.autor}</strong>
            <p>{m.texto}</p>
          </div>
        ))}
        <div ref={fimRef} />
      </div>

      <form className="composer" onSubmit={enviar}>
        <input
          value={texto}
          maxLength={2000}
          placeholder="Ex.: I need to go home."
          onChange={(e) => setTexto(e.target.value)}
          onFocus={() => !enviando && setEstado('ouvindo')}
          onBlur={() => !enviando && setEstado('idle')}
        />
        <button className="primario" disabled={enviando || !texto.trim()}>
          {enviando ? 'Enviando…' : 'Enviar'}
        </button>
      </form>
    </section>
  );
}
