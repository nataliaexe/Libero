// Cliente HTTP do Libero. A sessão fica no cookie HttpOnly emitido pelo servidor:
// nunca guardamos o token no localStorage.
export const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080';
export const IDOSO_PADRAO = import.meta.env.VITE_IDOSO_ID || 'dona-maria';

export async function req(path, options = {}) {
  const resposta = await fetch(API_URL + path, {
    credentials: 'include',
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
  });

  let dados = {};
  try {
    dados = await resposta.json();
  } catch {
    dados = {};
  }

  if (!resposta.ok) {
    const erro = new Error(dados.error || 'Não foi possível concluir esta ação.');
    erro.status = resposta.status;
    throw erro;
  }
  return dados;
}
